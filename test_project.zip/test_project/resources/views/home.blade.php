@extends('layouts.app')

@push('styles')
    <style>
        .session-message {
            position: fixed;
            width: 100%;
            overflow: hidden;
            top: 0px;
            height: 55px;
            left: 50%;
            z-index: 99999;
            transform: translate(-50%, 0%);
            display: none;
            flex-direction: column;
            align-content: center;
            justify-content: center;
            padding-top: 20px;
        }

        .session-message p {
            width: 100%;
            text-align: center;
            color: white;
            font-weight: bold;
        }

        .book-item {
            border: 1px solid white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            width: 20% !important;
            border-radius: 5px;
            background-color: #38c172;
        }

        .book-item p {
            color: white;
            font-size: 14px;
            padding: 5px
        }

        #john-shelf {
            height: 400px;
            width: 100%;
            border: 1px solid rgba(0, 0, 0, 0.3);
            border-radius: 5px;
        }

        #john-shelf .book-item {
            height: 100px;
        }

        #marc-shelf,
        #freddie-shelf,
        #ryan-shelf {
            height: 100px;
            border: 1px solid rgba(0, 0, 0, 0.3);
            border-radius: 5px;
        }

        #marc-shelf .book-item,
        #freddie-shelf .book-item,
        #ryan-shelf .book-item {
            height: 100%;
        }

        #table-body button {
            background-color: rgba(0, 0, 0, 0);
            border: none;
        }

    </style>
@endpush

@section('content')
    <div class="container">

        {{-- session mesage --}}
        <div class="session-message">
            <p></p>
        </div>

        <div class="row justify-content-center">
            <div class="body col-12 ">

                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" onclick="openModel()">
                    ADD BOOKS <span class="material-icons font-weight-bold" style="font-size: 12px">add</span>
                </button>

                <hr>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                {{-- form --}}

                                <div class="form">
                                    <div class="form-group">
                                        <label class="d-block">Book Name </label>
                                        <input class="form-control" type="text" id="book-name" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="d-block">Description </label>
                                        <textarea class="form-control" rows="5" id="book-description" required></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label class="d-block">Belongs To</label>
                                            <select id="belongs-to" class="form-control">
                                                <option value="John">John</option>
                                                <option value="Marc">Marc</option>
                                                <option value="Freddie">Freddie</option>
                                                <option value="Ryan">Ryan</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-6">
                                            <label class="d-block">State</label>
                                            <select id="book-state" class="form-control">
                                                <option value="active">Active</option>
                                                <option value="inactive">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button onclick="saveBooks()" class="btn btn-primary" id="save-edit-button">Save
                                            changes</button>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="book-shelf-container mt-4">
            <div class="row">
                <div class="col-6">
                    <h3>John BookShelf</h3>
                    <div class="d-flex align-content-start flex-wrap" id="john-shelf" ondrop="dropbook(event,'John')"
                        ondragover="allowDrop(event)">
                        {{-- john books will be listed here --}}
                    </div>
                </div>
                <div class="col-5 ml-3">
                    <h3>Marc BookShelf</h3>
                    <div class="row" id="marc-shelf" ondrop="dropbook(event,'Marc')" ondragover="allowDrop(event)">
                        {{-- john books will be listed here --}}
                    </div>
                    <h3 class="mt-2">Freddie BookShelf</h3>
                    <div class="row" id="freddie-shelf" ondrop="dropbook(event,'Freddie')" ondragover="allowDrop(event)">
                        {{-- john books will be listed here --}}
                    </div>
                    <h3 class="mt-2">Ryan BookShelf</h3>
                    <div class="row" id="ryan-shelf" ondrop="dropbook(event,'Ryan')" ondragover="allowDrop(event)">
                        {{-- john books will be listed here --}}
                    </div>
                </div>
            </div>
        </div>


        <div class="book-list-container mt-5">
            <table class="table table-striped">
                <thead class="bg-primary text-light">
                    <td>SN</td>
                    <td>Book Name</td>
                    <td>Given To</td>
                    <td>Given Date</td>
                    <td>Status</td>
                    <td>Action</td>
                </thead>
                <tbody id="table-body">

                </tbody>
            </table>
        </div>


    </div>

    <script>
        // session message
        function sessionMessage(bg, message) {
            $('.session-message').css('display', 'flex');
            $('.session-message').addClass(bg);
            $('.session-message p').html(message);
            $('.modal').modal('hide');
            setTimeout(() => {
                $('.session-message').removeClass(bg);
                $('.session-message').css('display', 'none');
            }, 2500);
        }

        // open model
        function openModel() {
            $('#book-name').val('');
            $('#book-description').val('');
            $('#belongs-to').val('John');
            $('#book-state').val('active');
            $('.modal').modal('show');
            $('#save-edit-button').attr('onclick', 'saveBooks()')
        }

    </script>

    {{-- javascript --}}
    <script>
        function saveBooks() {
            var book_name = $('#book-name').val();
            var book_description = $('#book-description').val();
            var belongs_to = $('#belongs-to').val();
            var state = $('#book-state').val();

            // validation
            if (book_name == '' || book_description == '') return false;


            $.ajax({
                url: '/api/book/create',
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    book_name: book_name,
                    book_description: book_description,
                    belongs_to: belongs_to,
                    state: state
                },
                success: function(data) {
                    if (data.success) {
                        sessionMessage('bg-success', data.success);
                        $('#john-shelf').html('');
                        $('#marc-shelf').html('');
                        $('#freddie-shelf').html('');
                        $('#ryan-shelf').html('');
                        loadBooks();

                    } else {
                        sessionMessage('bg-danger', data.error);
                    }
                },
                error: function(e) {
                    console.log(e);
                    sessionMessage('bg-danger', e.statusText);
                }
            })
        }

    </script>


    {{-- load db content to users bookshelf --}}
    <script>
        // loads the books on shelf when windows loads
        window.onload = function() {
            loadBooks();
            loadListBooks();
        }

        // on drag book 
        function dragbook(e, id) {
            e.dataTransfer.setData('text', e.target.id);
            e.dataTransfer.setData('id', id);
        }

        //  allowing to drop book on container shelf
        function allowDrop(e) {
            e.preventDefault();
        }

        // on drop book
        function dropbook(e, name) {
            e.preventDefault();
            var elem_id = e.dataTransfer.getData('text');
            var set_name = name;
            var book_id = e.dataTransfer.getData('id');


            $.ajax({
                url: '/api/book/' + book_id,
                method: "PUT",
                dataType: 'JSON',
                data: {
                    _token: '{{ csrf_token() }}',
                    _method: `{{ method_field('POST') }}`,
                    belongs_to: set_name,
                },
                success: function(data) {
                    console.log(data);
                    if (data.success) {
                        e.target.appendChild(document.getElementById(elem_id));
                        sessionMessage('bg-success', data.success);
                        $('#table-body').html('');
                        loadListBooks();
                    }
                    if (data.error) {
                        sessionMessage('bg-danger', data.error);
                    }

                },
                error: function(e) {
                    console.log(e);
                    sessionMessage('bg-danger', 'Failed to update.');
                }

            })

        }

        // load book function 
        function loadBooks() {

            $.ajax({
                url: '/api/book/list',
                method: "GET",
                type: "JSON",
                data: {
                    _token: '{{ csrf_token() }}',
                },
                success: function(data) {
                    var count = 1;
                    // console.log(data);
                    data.forEach(element => {

                        // john book shelf items
                        if (element['belongs_to'] == 'John') {

                            var html =
                                `<div id="book-${element.id}" class="book-item" ondragstart="dragbook(event,${element.id})" draggable="true" data-data="${element.id}">                                                
                                    <p class="heading-3 text-center">${element.book_name}</p>     
                                </div>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
                                `;

                            $('#john-shelf').append(html);
                        }
                        // marc book shelf items
                        if (element['belongs_to'] == 'Marc') {

                            var html =
                                `<div id="book-${element.id}" class="book-item" ondragstart="dragbook(event,${element.id})" draggable="true">
                                    <p class="heading-3 text-center"  >${element.book_name}</p>                                                                                                              
                                </div>                                                                                                                                                                                                                                                                                        
                                `;

                            $('#marc-shelf').append(html);
                        }
                        // freddie book shelf items
                        if (element['belongs_to'] == 'Freddie') {

                            var html =
                                `<div id="book-${element.id}" class="book-item" ondragstart="dragbook(event,${element.id})" draggable="true">
                                    <p class="heading-3 text-center"  >${element.book_name}</p>                                                                                                              
                                </div>                                                                                                                                                                                                                                                                                        
                                `;

                            $('#freddie-shelf').append(html);
                        }
                        // ryan book shelf items
                        if (element['belongs_to'] == 'Ryan') {

                            var html =
                                `<div id="book-${element.id}" class="book-item" ondragstart="dragbook(event,${element.id})" draggable="true">
                                    <p class="heading-3 text-center"  >${element.book_name}</p>                                                                                                              
                                </div>                                                                                                                                                                                                                                                                                        
                                `;

                            $('#ryan-shelf').append(html);
                        }
                    });
                }
            })

        }
        // load book function 
        function loadListBooks() {

            $.ajax({
                url: '/api/book/list',
                method: "GET",
                type: "JSON",
                data: {
                    _token: '{{ csrf_token() }}',
                },
                success: function(data) {
                    var count = 1;
                    // console.log(data);
                    data.forEach(element => {
                        var string = JSON.stringify(element);
                        var sanitize = string.replace("'", "//");
                        var date = element.updated_at.split('T')[0];
                        // book list
                        var book_list = `<tr id="book-list-${element.id}">`;                                                                                                                                                                 
                                book_list += `<td>${count}</td>`;
                                book_list += `<td>${element.book_name}</td>`;
                                book_list += `<td>${element.belongs_to}</td>`;                                
                                if (element.belongs_to != 'John'){
                                    book_list += `<td>${date}</td>`;
                                } else{
                                    book_list += `<td>-</td>` ;   
                                }                          
                                book_list += `<td>${element.state}</td>`; 
                                book_list += `<td>`;                            
                                book_list += `<button  onclick='openEditModal(${sanitize})'><i class="material-icons text-primary">edit</i></button>`;
                                book_list += `<button  onclick="deleteBook(${element.id})"><i class="material-icons text-danger">delete</i></button>`;
                                book_list += `</td>`;                                  
                                book_list += `</tr>`;
                                
                        $('#table-body').append(book_list);
                        count = count + 1;
                    })
                }
            })
        }



        // edit book modal 
        function openEditModal(elem) {
            $('.modal').modal('show');
            $('#book-name').val(elem.book_name);
            var desc = elem.book_description;
            $('#book-description').val(desc.replace("//", "'"));
            $('#belongs-to').val(elem.belongs_to);
            $('#book-state').val(elem.state);
            $('#save-edit-button').attr('onclick', `editBooks(${elem.id})`);
        }

        // edit books
        function editBooks(book_id) {
            var book_name = $('#book-name').val();
            var book_description = $('#book-description').val();
            var belongs_to = $('#belongs-to').val();
            var state = $('#book-state').val();
            var id = book_id;

            // validation
            if (book_name == '' || book_description == '') return false;


            $.ajax({
                url: '/api/book/' + id,
                method: 'PUT',
                data: {
                    _token: '{{ csrf_token() }}',
                    _method: `{{ method_field('POST') }}`,
                    book_name: book_name,
                    book_description: book_description,
                    belongs_to: belongs_to,
                    state: state
                },
                success: function(data) {
                    console.log(data);
                    if (data.success) sessionMessage('bg-success', data.success);
                    if (data.error) sessionMessage('bg-success', data.success);

                    $('#john-shelf').html('');
                    $('#marc-shelf').html('');
                    $('#freddie-shelf').html('');
                    $('#ryan-shelf').html('');
                    loadBooks();
                    $('#table-body').html('');
                    loadListBooks();

                },
                error: function(e) {
                    console.log(e);
                    sessionMessage('bg-danger', 'Failed to update.');
                }
            })
        }

        // delete book item
        function deleteBook(id) {

            var c = confirm('Are you sure want to delete');
            if (c == false) return false;


            $.ajax({
                url: '/api/book/' + id,
                method: "DELETE",
                dataType: "JSON",
                data: {
                    _token: '{{ csrf_token() }}',
                },
                success: function(data) {
                    if (data.success) {
                        sessionMessage('bg-success', data.success);
                        $('#john-shelf').html('');
                        $('#marc-shelf').html('');
                        $('#freddie-shelf').html('');
                        $('#ryan-shelf').html('');
                        loadBooks();
                        $('#table-body').html('');
                        loadListBooks();
                    }
                },
                error: function(e) {
                    console.log(e);
                    sessionMessage('bg-danger', 'Failed to delete.')
                }

            })
        }

    </script>




@endsection
