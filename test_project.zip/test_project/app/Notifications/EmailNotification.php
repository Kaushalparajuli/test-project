<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class EmailNotification extends Notification
{
    use Queueable;

    private $details;

    public function __construct($details)
    {
        $this->details = $details;
    }

    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->greeting('Dear' . $this->details['name'])
            ->line($this->details['message'])
            ->line('Thanks');
    }

    public function toArray($notifiable)
    {
        return [
            'order_id' => $this->details['user_email'],
        ];
    }
}