<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;

class BookController extends Controller
{
    public function create(Request $request)
    {
        $validatedData = $request->validate([
            'book_name' => 'required|string',
            'book_description' => 'required|string',
            'belongs_to' => 'required|string',
            'state' => 'required|string',
        ]);

        $book = new Book();
        $book_count = $book->all()->count();

        $book->book_name = $request->book_name;
        $book->book_description = $request->book_description;
        $book->belongs_to = $request->belongs_to;

        // check if shelf has already 20 books
        if ($book_count < 20) {

            if ($request->belongs_to == "John") {
                try {
                    $book->save();
                    $mesg = ['success' => 'Book Added Successfully.'];
                    return response()->json($mesg);
                } catch (\Throwable $e) {
                    return $e;
                }
            } else {
                $user_book_count = $book->where('belongs_to', $request->belongs_to)->get()->count();
                if ($user_book_count < 5) {
                    try {
                        $book->save();
                        $mesg = ['success' => 'Book Added Successfully.'];
                        return response()->json($mesg);
                    } catch (\Throwable $e) {
                        return $e;
                    }
                } else {
                    $mesg = ['error' => $belongs_to . ' Book Shelf is Full'];
                    return response()->json($mesg);
                }

            }

        } else {
            $mesg = ['error' => 'John already have 20 books'];
            return response()->json($mesg);
        }

    }

    public function show()
    {
        $book = Book::where('state', 'active')->get();
        if ($book->count() != 0) {
            return response()->json($book);
        }
    }

    public function update(Request $request, $id)
    {

        $update = Book::find($id);
        $update->belongs_to = $request->belongs_to;
        if ($request->book_name) {
            $update->book_name = $request->book_name;
        }
        if ($request->book_description) {
            $update->book_description = $request->book_description;
        }
        if ($request->state) {
            $update->state = $request->state;
        }

        // checking if name is john
        if ($request->belongs_to == 'John') {
            try {
                $update->update();
                if ($update) {
                    $mesg = ['success' => 'Book Updated Successfully.'];
                    return response()->json($mesg);
                }

            } catch (\Throwable $e) {
                return $e;
            }

        } else {
            $user_book = Book::all()->where('belongs_to', $request->belongs_to);
            // check if shelf has already 5 books
            if ($user_book->count() < 5) {
                try {
                    $update->update();
                    if ($update) {
                        $mesg = ['success' => 'Book Updated Successfully.'];
                        return response()->json($mesg);
                    }

                } catch (\Throwable $e) {
                    return $e;
                }
            } else {
                $mesg = ['error' => $request->belongs_to . ' Book Shelf is Full'];
                return response()->json($mesg);
            }

        }

    }

    public function delete($id)
    {
        try {
            $delete = Book::find($id);
            $delete->delete();
            if ($delete) {
                $mesg = ['success' => 'Book deleted Successfully.'];
                return response()->json($mesg);
            }
        } catch (\Throwable $e) {
            return $e;
        }
    }

}